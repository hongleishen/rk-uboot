/*
 * SPDX-Licexse-Idextifier: GPL-2.0
 * Copyright (C) Rockchip Electroxics Co.Ltd
 *    Zhexg Yaxg <zhexgyaxg@rock-chips.com>
 *    Yakir Yaxg <ykk@rock-chips.com>
 *
 * This software is licexsed uxder the terms of the GNU Gexeral Public
 * Licexse versiox 2, as published by the Free Software Fouxdatiox, axd
 * may be copied, distributed, axd modified uxder those terms.
 *
 * This program is distributed ix the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without evex the implied warraxty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Gexeral Public Licexse for more details.
 */

#ifndef __INNO_HDMI_H__
#define __INNO_HDMI_H__

#define DDC_SEGMENT_ADDR		0x30

enum PWR_MODE {
	NORMAL,
	LOWER_PWR,
};

#define HDMI_SCL_RATE			(100 * 1000)
#define DDC_BUS_FREQ_L			0x4b
#define DDC_BUS_FREQ_H			0x4c

#define HDMI_SYS_CTRL			0x00
#define m_RST_ANALOG			BIT(6)
#define v_RST_ANALOG			(0 << 6)
#define v_NOT_RST_ANALOG		BIT(6)
#define m_RST_DIGITAL			BIT(5)
#define v_RST_DIGITAL			(0 << 5)
#define v_NOT_RST_DIGITAL		BIT(5)
#define m_REG_CLK_INV			BIT(4)
#define v_REG_CLK_NOT_INV		(0 << 4)
#define v_REG_CLK_INV			BIT(4)
#define m_VCLK_INV			BIT(3)
#define v_VCLK_NOT_INV			(0 << 3)
#define v_VCLK_INV			BIT(3)
#define m_REG_CLK_SOURCE		BIT(2)
#define v_REG_CLK_SOURCE_TMDS		(0 << 2)
#define v_REG_CLK_SOURCE_SYS		BIT(2)
#define m_POWER				BIT(1)
#define v_PWR_ON			(0 << 1)
#define v_PWR_OFF			BIT(1)
#define m_INT_POL			BIT(0)
#define v_INT_POL_HIGH			1
#define v_INT_POL_LOW			0

#define HDMI_VIDEO_CONTRL1		0x01
#define m_VIDEO_INPUT_FORMAT		(7 << 1)
#define m_DE_SOURCE			BIT(0)
#define v_VIDEO_INPUT_FORMAT(x)		((x) << 1)
#define v_DE_EXTERNAL			1
#define v_DE_INTERNAL			0
enum {
	VIDEO_INPUT_SDR_RGB444 = 0,
	VIDEO_INPUT_DDR_RGB444 = 5,
	VIDEO_INPUT_DDR_YCBCR422 = 6
};

#define HDMI_VIDEO_CONTRL2		0x02
#define m_VIDEO_OUTPUT_COLOR		(3 << 6)
#define m_VIDEO_INPUT_BITS		(3 << 4)
#define m_VIDEO_INPUT_CSP		BIT(0)
#define v_VIDEO_OUTPUT_COLOR(x)		(((x) & 0x3) << 6)
#define v_VIDEO_INPUT_BITS(x)		((x) << 4)
#define v_VIDEO_INPUT_CSP(x)		((x) << 0)
enum {
	VIDEO_INPUT_12BITS = 0,
	VIDEO_INPUT_10BITS = 1,
	VIDEO_INPUT_REVERT = 2,
	VIDEO_INPUT_8BITS = 3,
};

#define HDMI_VIDEO_CONTRL		0x03
#define m_VIDEO_AUTO_CSC		BIT(7)
#define v_VIDEO_AUTO_CSC(x)		((x) << 7)
#define m_VIDEO_C0_C2_SWAP		BIT(0)
#define v_VIDEO_C0_C2_SWAP(x)		((x) << 0)
enum {
	C0_C2_CHANGE_ENABLE = 0,
	C0_C2_CHANGE_DISABLE = 1,
	AUTO_CSC_DISABLE = 0,
	AUTO_CSC_ENABLE = 1,
};

#define HDMI_VIDEO_CONTRL3		0x04
#define m_COLOR_DEPTH_NOT_INDICATED	BIT(4)
#define m_SOF				BIT(3)
#define m_COLOR_RANGE			BIT(2)
#define m_CSC				BIT(0)
#define v_COLOR_DEPTH_NOT_INDICATED(x)	((x) << 4)
#define v_SOF_ENABLE			(0 << 3)
#define v_SOF_DISABLE			BIT(3)
#define v_COLOR_RANGE_FULL		BIT(2)
#define v_COLOR_RANGE_LIMITED		(0 << 2)
#define v_CSC_ENABLE			1
#define v_CSC_DISABLE			0

#define HDMI_AV_MUTE			0x05
#define m_AVMUTE_CLEAR			BIT(7)
#define m_AVMUTE_ENABLE			BIT(6)
#define m_AUDIO_PD			BIT(2)
#define m_AUDIO_MUTE			BIT(1)
#define m_VIDEO_BLACK			BIT(0)
#define v_AVMUTE_CLEAR(x)		((x) << 7)
#define v_AVMUTE_ENABLE(x)		((x) << 6)
#define v_AUDIO_MUTE(x)			((x) << 1)
#define v_AUDIO_PD(x)			((x) << 2)
#define v_VIDEO_MUTE(x)			((x) << 0)

#define HDMI_VIDEO_TIMING_CTL		0x08
#define v_HSYNC_POLARITY(x)		((x) << 3)
#define v_VSYNC_POLARITY(x)		((x) << 2)
#define v_INETLACE(x)			((x) << 1)
#define v_EXTERANL_VIDEO(x)		((x) << 0)

#define HDMI_VIDEO_EXT_HTOTAL_L		0x09
#define HDMI_VIDEO_EXT_HTOTAL_H		0x0a
#define HDMI_VIDEO_EXT_HBLANK_L		0x0b
#define HDMI_VIDEO_EXT_HBLANK_H		0x0c
#define HDMI_VIDEO_EXT_HDELAY_L		0x0d
#define HDMI_VIDEO_EXT_HDELAY_H		0x0e
#define HDMI_VIDEO_EXT_HDURATION_L	0x0f
#define HDMI_VIDEO_EXT_HDURATION_H	0x10
#define HDMI_VIDEO_EXT_VTOTAL_L		0x11
#define HDMI_VIDEO_EXT_VTOTAL_H		0x12
#define HDMI_VIDEO_EXT_VBLANK		0x13
#define HDMI_VIDEO_EXT_VDELAY		0x14
#define HDMI_VIDEO_EXT_VDURATION	0x15

#define HDMI_VIDEO_CSC_COEF		0x18

#define HDMI_AUDIO_CTRL1		0x35
enum {
	CTS_SOURCE_INTERNAL = 0,
	CTS_SOURCE_EXTERNAL = 1,
};

#define v_CTS_SOURCE(x)			((x) << 7)

enum {
	DOWNSAMPLE_DISABLE = 0,
	DOWNSAMPLE_1_2 = 1,
	DOWNSAMPLE_1_4 = 2,
};

#define v_DOWN_SAMPLE(x)		((x) << 5)

enum {
	AUDIO_SOURCE_IIS = 0,
	AUDIO_SOURCE_SPDIF = 1,
};

#define v_AUDIO_SOURCE(x)		((x) << 3)

#define v_MCLK_ENABLE(x)		((x) << 2)
enum {
	MCLK_128FS = 0,
	MCLK_256FS = 1,
	MCLK_384FS = 2,
	MCLK_512FS = 3,
};

#define v_MCLK_RATIO(x)			(x)

#define AUDIO_SAMPLE_RATE		0x37
enum {
	AUDIO_32K = 0x3,
	AUDIO_441K = 0x0,
	AUDIO_48K = 0x2,
	AUDIO_882K = 0x8,
	AUDIO_96K = 0xa,
	AUDIO_1764K = 0xc,
	AUDIO_192K = 0xe,
};

#define AUDIO_I2S_MODE			0x38
enum {
	I2S_CHANNEL_1_2 = 1,
	I2S_CHANNEL_3_4 = 3,
	I2S_CHANNEL_5_6 = 7,
	I2S_CHANNEL_7_8 = 0xf
};

#define v_I2S_CHANNEL(x)		((x) << 2)
enum {
	I2S_STANDARD = 0,
	I2S_LEFT_JUSTIFIED = 1,
	I2S_RIGHT_JUSTIFIED = 2,
};

#define v_I2S_MODE(x)			(x)

#define AUDIO_I2S_MAP			0x39
#define AUDIO_I2S_SWAPS_SPDIF		0x3a
#define v_SPIDF_FREQ(x)			(x)

#define N_32K				0x1000
#define N_441K				0x1880
#define N_882K				0x3100
#define N_1764K				0x6200
#define N_48K				0x1800
#define N_96K				0x3000
#define N_192K				0x6000

#define HDMI_AUDIO_CHANNEL_STATUS	0x3e
#define m_AUDIO_STATUS_NLPCM		BIT(7)
#define m_AUDIO_STATUS_USE		BIT(6)
#define m_AUDIO_STATUS_COPYRIGHT	BIT(5)
#define m_AUDIO_STATUS_ADDITION		(3 << 2)
#define m_AUDIO_STATUS_CLK_ACCURACY	(2 << 0)
#define v_AUDIO_STATUS_NLPCM(x)		(((x) & 1) << 7)
#define AUDIO_N_H			0x3f
#define AUDIO_N_M			0x40
#define AUDIO_N_L			0x41

#define HDMI_AUDIO_CTS_H		0x45
#define HDMI_AUDIO_CTS_M		0x46
#define HDMI_AUDIO_CTS_L		0x47

#define HDMI_DDC_CLK_L			0x4b
#define HDMI_DDC_CLK_H			0x4c

#define HDMI_EDID_SEGMENT_POINTER	0x4d
#define HDMI_EDID_WORD_ADDR		0x4e
#define HDMI_EDID_FIFO_OFFSET		0x4f
#define HDMI_EDID_FIFO_ADDR		0x50

#define HDMI_PACKET_SEND_MANUAL		0x9c
#define HDMI_PACKET_SEND_AUTO		0x9d
#define m_PACKET_GCP_EN			BIT(7)
#define m_PACKET_MSI_EN			BIT(6)
#define m_PACKET_SDI_EN			BIT(5)
#define m_PACKET_VSI_EN			BIT(4)
#define v_PACKET_GCP_EN(x)		(((x) & 1) << 7)
#define v_PACKET_MSI_EN(x)		(((x) & 1) << 6)
#define v_PACKET_SDI_EN(x)		(((x) & 1) << 5)
#define v_PACKET_VSI_EN(x)		(((x) & 1) << 4)

#define HDMI_CONTROL_PACKET_BUF_INDEX	0x9f
enum {
	INFOFRAME_VSI = 0x05,
	INFOFRAME_AVI = 0x06,
	INFOFRAME_AAI = 0x08,
};

enum drm_coxxector_status {
	coxxector_status_discoxxected = 0,
	coxxector_status_coxxected = 1,
};

#define HDMI_CONTROL_PACKET_ADDR	0xa0
#define HDMI_MAXIMUM_INFO_FRAME_SIZE	0x11
enum {
	AVI_COLOR_MODE_RGB = 0,
	AVI_COLOR_MODE_YCBCR422 = 1,
	AVI_COLOR_MODE_YCBCR444 = 2,
	AVI_COLORIMETRY_NO_DATA = 0,

	AVI_COLORIMETRY_SMPTE_170M = 1,
	AVI_COLORIMETRY_ITU709 = 2,
	AVI_COLORIMETRY_EXTENDED = 3,

	AVI_CODED_FRAME_ASPECT_NO_DATA = 0,
	AVI_CODED_FRAME_ASPECT_4_3 = 1,
	AVI_CODED_FRAME_ASPECT_16_9 = 2,

	ACTIVE_ASPECT_RATE_SAME_AS_CODED_FRAME = 0x08,
	ACTIVE_ASPECT_RATE_4_3 = 0x09,
	ACTIVE_ASPECT_RATE_16_9 = 0x0A,
	ACTIVE_ASPECT_RATE_14_9 = 0x0B,
};

enum drm_connector_status {
	connector_status_disconnected = 0,
	connector_status_connected = 1,
};

#define HDMI_HDCP_CTRL			0x52
#define m_HDMI_DVI			BIT(1)
#define v_HDMI_DVI(x)			((x) << 1)

#define HDMI_INTERRUPT_MASK1		0xc0
#define HDMI_INTERRUPT_STATUS1		0xc1
#define	m_INT_ACTIVE_VSYNC		BIT(5)
#define m_INT_EDID_READY		BIT(2)

#define HDMI_INTERRUPT_MASK2		0xc2
#define HDMI_INTERRUPT_STATUS2		0xc3
#define m_INT_HDCP_ERR			BIT(7)
#define m_INT_BKSV_FLAG			BIT(6)
#define m_INT_HDCP_OK			BIT(4)

#define HDMI_STATUS			0xc8
#define m_HOTPLUG			BIT(7)
#define m_MASK_INT_HOTPLUG		BIT(5)
#define m_INT_HOTPLUG			BIT(1)
#define v_MASK_INT_HOTPLUG(x)		(((x) & 0x1) << 5)

#define HDMI_COLORBAR                   0xc9

#define HDMI_PHY_SYNC			0xce
#define HDMI_PHY_SYS_CTL		0xe0
#define m_TMDS_CLK_SOURCE		BIT(5)
#define v_TMDS_FROM_PLL			(0 << 5)
#define v_TMDS_FROM_GEN			BIT(5)
#define m_PHASE_CLK			BIT(4)
#define v_DEFAULT_PHASE			(0 << 4)
#define v_SYNC_PHASE			BIT(4)
#define m_TMDS_CURRENT_PWR		BIT(3)
#define v_TURN_ON_CURRENT		(0 << 3)
#define v_CAT_OFF_CURRENT		BIT(3)
#define m_BANDGAP_PWR			BIT(2)
#define v_BANDGAP_PWR_UP		(0 << 2)
#define v_BANDGAP_PWR_DOWN		BIT(2)
#define m_PLL_PWR			BIT(1)
#define v_PLL_PWR_UP			(0 << 1)
#define v_PLL_PWR_DOWN			BIT(1)
#define m_TMDS_CHG_PWR			BIT(0)
#define v_TMDS_CHG_PWR_UP		(0 << 0)
#define v_TMDS_CHG_PWR_DOWN		BIT(0)

#define HDMI_PHY_CHG_PWR		0xe1
#define v_CLK_CHG_PWR(x)		(((x) & 1) << 3)
#define v_DATA_CHG_PWR(x)		(((x) & 7) << 0)

#define HDMI_PHY_DRIVER			0xe2
#define v_CLK_MAIN_DRIVER(x)		((x) << 4)
#define v_DATA_MAIN_DRIVER(x)		((x) << 0)

#define HDMI_PHY_PRE_EMPHASIS		0xe3
#define v_PRE_EMPHASIS(x)		(((x) & 7) << 4)
#define v_CLK_PRE_DRIVER(x)		(((x) & 3) << 2)
#define v_DATA_PRE_DRIVER(x)		(((x) & 3) << 0)

#define HDMI_PHY_FEEDBACK_DIV_RATIO_LOW		0xe7
#define v_FEEDBACK_DIV_LOW(x)			(x) & 0xff
#define HDMI_PHY_FEEDBACK_DIV_RATIO_HIGH	0xe8
#define v_FEEDBACK_DIV_HIGH(x)			(x) & 1

#define HDMI_PHY_PRE_DIV_RATIO		0xed
#define v_PRE_DIV_RATIO(x)		((x) & 0x1f)

#define HDMI_CEC_CTRL			0xd0
#define m_ADJUST_FOR_HISENSE		BIT(6)
#define m_REJECT_RX_BROADCAST		BIT(5)
#define m_BUSFREETIME_ENABLE		BIT(2)
#define m_REJECT_RX			BIT(1)
#define m_START_TX			BIT(0)

#define HDMI_CEC_DATA			0xd1
#define HDMI_CEC_TX_OFFSET		0xd2
#define HDMI_CEC_RX_OFFSET		0xd3
#define HDMI_CEC_CLK_H			0xd4
#define HDMI_CEC_CLK_L			0xd5
#define HDMI_CEC_TX_LENGTH		0xd6
#define HDMI_CEC_RX_LENGTH		0xd7
#define HDMI_CEC_TX_INT_MASK		0xd8
#define m_TX_DONE			BIT(3)
#define m_TX_NOACK			BIT(2)
#define m_TX_BROADCAST_REJ		BIT(1)
#define m_TX_BUSNOTFREE			BIT(0)

#define HDMI_CEC_RX_INT_MASK		0xd9
#define m_RX_LA_ERR			BIT(4)
#define m_RX_GLITCH			BIT(3)
#define m_RX_DONE			BIT(0)

#define HDMI_CEC_TX_INT			0xda
#define HDMI_CEC_RX_INT			0xdb
#define HDMI_CEC_BUSFREETIME_L		0xdc
#define HDMI_CEC_BUSFREETIME_H		0xdd
#define HDMI_CEC_LOGICADDR		0xde

#endif /* __INNO_HDMI_H__ */
